from console_gfx import ConsoleGfx

# function definitions
def count_runs(flat):
    pass

if __name__ == '__main__':
    # main program
    image_data = None
    # print welcome message statement to user
    print("Welcome to the RLE image encoder!")
    print()

    # print statement for spectrum
    # and display the test_rainbow spectrum image to user
    print("Displaying Spectrum Image")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()
    print()

    menu = -1
    while menu != 0:
        # TA Karen provided debugging help with looping issue
        # use while loop to keep prompting the user to select a menu option
        # display RLE menu for user to select an option
        print("RLE Menu")
        print(str("-") * 8)
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print()

        # prompt the user for menu option from menu
        menu = int(input("Select a Menu Option: "))

        if menu == 1:
            # prompt user for file to load
            # and then store data inside image_data
            filename = input("Enter name of file to load: ")
            image_data = ConsoleGfx.load_file(filename)
            print()
        elif menu == 2:
            # store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
            print()
        elif menu == 6:
            # call display_image in ConsoleGfx on image_data
            # to output image to screen
            if image_data == None:
                print("Displaying image...\n(no data)")
                print()
            else:
                print("Displaying image...")
                ConsoleGfx.display_image(image_data)
                print()
        else:
            # if user selects menu option not in menu
            # print error message
            if menu < 0 or menu > 9:
                print("Error! Invalid input.")
                print()
