from console_gfx import ConsoleGfx

# function definitions







# main program
if __name__ == '__main__':
    # initialize the image_date
    image_data = None

    # 1) Display welcome message
    print("Welcome to the RLE image encoder!\n")

    # 2) Display color test (ConsoleGfx.testRainbow)
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3) Display the menu
    print(f"\n\nRLE Menu\n"
          f"--------\n"
          f"0. Exit\n"
          f"1. Load File\n"
          f"2. Load Test Image\n"
          f"3. Read RLE String\n"
          f"4. Read RLE Hex String\n"
          f"5. Read Data Hex string\n"
          f"6. Display Image\n"
          f"7. Display RLE String\n"
          f"8. Display Hex RLE Data\n"
          f"9. Display Hex Flat Data\n")

    # 4) Prompt for input to get the option
    menu = int(input("Select a Menu Option: "))

    # use while loop to keep prompting the user to choose a menu option
    while menu != 0:
        # 1. Load File - load file and store the data inside image_data
        if menu == 1:
            # prompt the user for the file name
            filename=input("Enter name of file to load: ")
            # caLl ConsoleGfx.load_file(filename) and store returned value in image_data
            image_data=ConsoleGfx.load_file(filename)

        # 2. Load Test Image
        if menu == 2:
            # store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        # 6. Display Image
        if menu == 6:
            # call display_image in ConsoleGfx on image_data
            ConsoleGfx.display_image(image_data)

        # get option for the new loop and for the conditional judgement
        menu = int(input("\nSelect a Menu Option: "))
