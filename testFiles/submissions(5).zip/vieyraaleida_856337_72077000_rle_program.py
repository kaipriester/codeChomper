#Fall 2022 COP3502C Project 2A:

#Aleida Vieyra

from console_gfx import ConsoleGfx


print(ConsoleGfx.test_rainbow)

def main():
        # if __name-- ==__main__:
        # main program
    #image_data = None
    print("")

print("Welcome to the RLE Image encoder!")
# From instructions: Display "Welcome messages" in output
print("")

# Display the test_rainbow (spectrum) using the following code:
print("Displaying Spectrum Image:")  # Display the test_rainbow (spectrum) using the following code:

print(ConsoleGfx.display_image(ConsoleGfx.test_rainbow))
    # Create a while loop (i.e.) to continue prompting the user to choose a menu option

#ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
#To make colors in output match without instruction's colors...
# we have to go to settings to select color scheme provided

#Function definitions




#Next provide a define menu function and provide menu option...
def menu():
    print("")
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")



menu_start = False

menu()
print("")
print("Select a menu option: ")
menu_option = int(input())


while not menu_start:
    print("")

    if menu_option == 1:
        print("Enter name of file to load:")
        filename = input()
        print(ConsoleGfx.load_file(str(filename)))
        image_data = filename
        menu_start = True
    if menu_option == 2:
        filename = str(input())
        print(ConsoleGfx.test_image(str(filename)))
        image_data += ConsoleGfx.test_image(str(filename))
        print("Test image data loaded.")
        continue
        menu_start = True
    if menu_option == 6:
        filename = str(input())
        image_data = ConsoleGfx.test_image(str(filename))
        print(ConsoleGfx.display_image(image_data))
        menu_start = True

menu_start = False
        # Prompt user for a menu option! (below are the options selections and instructions fo each selection)
        # Option 1:
            #Load the file and store data inside image data (variable)
            # function "load file" is already defined from the imported file above
            # Call ConsoleGfx.load_file(file name) and store return value in image data

        #Option 2:
            #Store ConsoleGfx.test_image in image_data

        #Option 6
            #call display_image in ConsolfeGfx on image_data