from console_gfx import ConsoleGfx



if __name__ == '__main__':
    # varibles
    looped = True
    im_data = None
    # Welcome
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()

    #Menu loop
    while looped:
        #Menu
        print("RLE Menu\n--------\n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex String\n5. Display Image\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex Flat Data\n")
        in1 = int(input("Select a Menu Option: "))
        #Selection Logic
        #End Program
        if in1 == 0:
            looped = False
            break
        #Opt1
        elif in1 == 1:
            file = input("Enter name of file to load: ")
            im_data = ConsoleGfx.load_file(file)
        #Opt2
        elif in1 == 2:
            im_data = ConsoleGfx.test_image
        # Opt6
        elif in1 == 6:
            print("Displaying image...")
            ConsoleGfx.display_image(im_data)
        # Invalid Option
        else:
            print("Error! Invalid Input")

        #Opt3
        """
        Options 3-5 and 7-9 are placeholders for the final code options
        Only Options 1,2, and 6 work as well as the error message and program exit.
        3-5 and 7-9 are set as comments for now
        elif in1 == 3:
            print(3)
        #Opt4
        elif in1 == 4:
            print(4)
        #Opt5
        elif in1 == 5:
            print(5)
        #Opt6
        elif in1 == 6:
            print("Displaying image...")
            ConsoleGfx.display_image(im_data)
        #Opt7
        elif in1 == 7:
            print(7)
        #Opt8
        elif in1 == 8:
            print(8)
        #Opt9
        elif in1 == 9:
            print(9)
        #Invalid Option
        else:
            print("Error! Invalid Input")
        """
        #Adding Whitespace to match output
        print()