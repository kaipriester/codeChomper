from fileinput import filename
from msilib.schema import File
from console_gfx import ConsoleGfx

def main():

  print("Welcome to the RLE image encoder!")
  print('')
  print("Displaying Spectrum Image:")
  ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

  def menu():

    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hes Flat Data")
    print('')

  menu()

  while(True):
    
      try:

        option = int(input("Select a Menu Option: "))
        
        if option in range(0,10):

          if option == 0:
            quit()

          if option == 1:

            try:
              filename = ConsoleGfx.load_file(input("Enter name of file to load: "))
              
            except FileNotFoundError:
              print("File not found.")
              menu()

          if option == 2:
            filename = ConsoleGfx.test_image
            print("Test image data loaded.")
            menu()
  
          try:

            if option == 6:
              ConsoleGfx.display_image(filename)
              filename = None
              menu()

          except TypeError:
            print("No file loaded.")
            
          except UnboundLocalError:
            print("No file loaded.")

        else:
          print("Please enter an integer value between 0 and 9.")

      except ValueError:
        print("Please enter an integer value between 0 and 9.")

main()

