

from console_gfx import ConsoleGfx

print("Welcome to the RLE image encoder!")
print()
print("Displaying Spectrum Image:")

ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

# Menu
menu = -1
while menu != 0:
    print()
    print()
    print("RLE MENU")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display image")
    print("7. Display RlE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")

    num = float(input("Select a Menu Option:"))
# Option 1
    if num == 1:
        file = ConsoleGfx.load_file(input("enter name of file to load:"))
# Option 2
    if num == 2:
        print('text data loaded')
    file = ConsoleGfx.test_image
# Option 3
    if num == 6:
        ConsoleGfx.display_image(file)













