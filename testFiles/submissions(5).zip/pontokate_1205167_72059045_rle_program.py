
from console_gfx import ConsoleGfx

image_data = ''
menu_num = 10

##def spectrum_image():
    #0a

print("Welcome to the RLE image encoder:")
print("")
print("Displaying Spectrum Image:")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
print("")
print("")

while menu_num != 0:
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")
    print("")
    menu_num = int(input("Select a Menu Option: "))

    if menu_num == 1:
        filename = input("Enter name of file to load: ")
        image_data = ConsoleGfx.load_file(filename)
        print("")
    elif menu_num == 2:
        print("Test image data loaded.")
        image_data = ConsoleGfx.test_image
        print("")
    elif menu_num == 6:
        print("Displaying image...")
        ConsoleGfx.display_image(image_data)
        print("")