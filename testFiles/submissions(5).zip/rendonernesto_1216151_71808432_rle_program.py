# Ernesto Rendon
# Project 2A - RLE with Images Python
# September 23, 2022

# Importing necessary classes and methods from console_gfx.py file
from console_gfx import ConsoleGfx

# Function simply prints out options to user
def print_menu_options():
    print('RLE Menu')
    print('-' * 8)
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data\n')

# Function will try to open string filename entered in by user
def load_file():

    # Prompt user for filename input, and will set user_file variable to result of method .load_file
    try:
        user_file = ConsoleGfx.load_file(input('Enter name of the file to load: '))

    # Exception is triggered if the filename passed in CANNOT be found; throw error and set user_file to None
    except:
        print('Error! Invalid input.\n')
        user_file = None

    # Print new-line for aesthetics
    print()

    # Return the user file to main function, either as a matching file, or None (no match)
    return user_file


# Statements here will only run if .py file is called as a solo module
if __name__ == '__main__':

    # Initializing image_data variable
    image_data = None

    # Prompting welcome message and rainbow graphic to user
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()

    # Initializing user-input variable
    menu_choice = 1

    '''
    As per project 2a rules, only options 1, 2, and 6 are functional at this time; any other acceptable range 
    integer input will do nothing and continue the loop
    '''
    while menu_choice != 0:

        # Call to function that displays menu choices to user
        print_menu_options()

        # Ask user for integer input from menu options
        try:
            menu_choice = int(input('Select a Menu Option: '))

            # If user enters 0, leave loop and end program
            if menu_choice == 0:
                continue

        # If non-numerical chars are in input, throw error and ask for input again
        except:
            print('Error! Invalid input.\n')
            continue

        # If input is not within defined range of options, throw error and ask for input again
        if not(0<=menu_choice <= 9):
            print('Error! Invalid input.\n')
            continue

        # Option 1 sets image_data variable equal to output of defined file-loading function
        if menu_choice == 1:
            image_data = load_file()

        # Option 2 loads up default test image (Gator)
        elif menu_choice == 2:
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.\n')

        # Option 6 displays currently stored image in image_data object
        elif menu_choice == 6:
            print('Displaying image...')

            # If current image data is empty, display to user, and continue to next loop iteration
            if image_data == None:
                print('(no data)\n')
                continue

            # Otherwise, print out the loaded image data to user; then continue to next loop iteration
            else:
                ConsoleGfx.display_image(image_data)
                print()
