# Project 2A RLE with Images Python
# This program will encode and decode images using run-length encoding

# import ConsoleGfx
from console_gfx import ConsoleGfx

# functon definitions


# main function
if __name__ == '__main__':
    # main program
    image_data = None
    # 1. welcome message
    print("Welcome to the RLE image encoder!")
    # 2. display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print("")
    print("")

    # 3. use while loop to keep prompting user to choose menu option
    menu = 1 # on/off switch for menu
    while menu != 0:
        # print menu
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print("")


        # 4. prompt user for menu option
        menu_input = int(input("Select a Menu Option: "))
        # option 1
            # load file and store data inside image_data
        if menu_input == 1:
            # prompt for file name
            file_in = input("Enter name of file to load: ")
            # call ConsoleGFx.load_file(filename) and store return value in image_data
            image_data = ConsoleGfx.load_file(file_in)
            print("")
        # option 2
            # store ConsoleGfx.test_image in image_data
        elif menu_input == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
            print("")

        # option 6
            # call display_image in ConsoleGfx on image_data
        elif menu_input ==6:
            print("Displaying image...")
            ConsoleGfx.display_image(image_data)
            print("")