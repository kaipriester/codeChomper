from console_gfx import ConsoleGfx

# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # Main Program

    # Initially we don't know what image data is.
    image_data = None
    # Welcome Message
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image: ")
    # Show test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print("\n")
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")

    user_option = -1
    image_data = None

    while user_option != 0:
        user_option = int(input("Select a Menu Option:"))

        # Option 1
        # Load file and store the data inside image_data
        if user_option == 1:
            file_name = input("Enter name of file to load:")
            image_data = ConsoleGfx.load_file(file_name)

        # Option 2
        #Load the test image
        if user_option == 2:
            image_data = ConsoleGfx.test_image

        # Options 6
        # call display_image in ConsoleGfx on image_data
        if user_option == 6:
            ConsoleGfx.display_image(image_data)

