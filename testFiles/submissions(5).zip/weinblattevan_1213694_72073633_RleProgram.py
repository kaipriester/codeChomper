from console_gfx import ConsoleGfx as CG

filename = []

def print_menu():
    global filename

    print("\nRLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")
    print("Select a Menu Option:")

    menuSelect = int(input())


    if(menuSelect == 1):
        fileInput = str(input())
        filename = CG.load_file(fileInput)
        print_menu()

    if(menuSelect == 2):
        filename = CG.test_image
        print_menu()

    if(menuSelect == 6):
        CG.display_image(filename)
        print_menu()

    if(menuSelect == 0):
        exit()

def main():
    image_data = None

    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    CG.display_image(CG.test_rainbow)
    print()
    print_menu()


main()
