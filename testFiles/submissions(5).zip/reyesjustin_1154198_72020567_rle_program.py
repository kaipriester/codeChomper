from console_gfx import ConsoleGfx

# notes/walk through from project 2a overview lecture
# delete when done with project
'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''
'''
# function definitions
def count_runs(flat):
    pass

if __name__ == '__main__':
    # main program
    image_data = None
    # 1. welcome messages
    # 2. display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. use while loop to keep prompting the user to choose a menu option
    menu = -1
    while menu != 0:
        # 4 prompt user for menu option
        # option 1
            # load file and store data inside image_data
                # prompt for the file name
                # call ConsoleGfx.load_file(filename) and store returned value in image_data

        # option 2
            # store ConsoleGfx.test_image in image_data

        # option 6
            # call display image in ConsoleGfx on image_data
'''

if __name__ == '__main__':

    # stores image data
    image_data = None

    # prints welcome message and test image
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print('\n')

    # prints menu and assigns variable to run while loop
    run = 1

    while run != 0:

        # prints menu
        print('\nRLE Menu\n--------\n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n'
              '4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image\n7. Display RLE String\n'
              '8. Display Hex RLE Data\n9. Display Hex Flat Data\n')

        # gets user choice from menu
        choice = int(input('Select a Menu Option: '))

        # chooses what to do based on user choice
        if choice == 0:

            # ends while loop
            run = 0

        elif choice == 1:

            # user chooses and then loads file
            filename = input('Enter name of file to load: ')
            image_data = ConsoleGfx.load_file(filename)

        elif choice == 2:

            # loads ConsoleGfx.testImage
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.')

        # elif choice == 3:
        #
        # elif choice == 4:
        #
        # elif choice == 5:

        elif choice == 6:

            # cancels program if there is no image data already loaded
            if image_data == None:

                run = 0

            else:

                # displays image
                ConsoleGfx.display_image(image_data)

        # elif choice == 7:
        #
        # elif choice == 8:
        #
        # elif choice == 9:

        else:

            # runs while loop again for invalid input
            pass


