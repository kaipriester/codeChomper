from console_gfx import ConsoleGfx


# function definitions
def count_runs(flat):
    pass


def print_menu():
    print()
    print("RLE Menu\n--------\n0. Exit\n1. Load File"
          "\n2. Load Test Image\n3. Read RLE String"
          "\n4. Read RLE Hex String\n5. Read Data Hex String"
          "\n6. Display Image\n7. Display RLE String"
          "\n8. Display Hex RLE Data\n9. Display Hex Flat Data")


# main program for zyBooks
if __name__ == '__main__':
    image_data = None
    rle = True
    while rle:
        print("Welcome to the RLE image encoder!", "\n")
        print("Displaying Spectrum Image:")
        ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
        print()
        # while loop to keep prompting menu
        menu = True
        while menu:
            print_menu()
            print()
            menu_selection = int(input("Select a Menu Option: "))
            if menu_selection == 0:
                menu = False
                rle = False
                pass
            # option 1
            # load file and store data inside image_data
            # call ConsoleGfx.load_file(filename) and store returned data
            if menu_selection == 1:
                filename = input("Enter name of file to load: ")
                image_data = ConsoleGfx.load_file(filename)
            # option 2
            # store ConsoleGfx.test_image in image_data
            if menu_selection == 2:
                image_data = ConsoleGfx.test_image
                print("Test image data loaded.")
            if menu_selection == 3:
                pass
            if menu_selection == 4:
                pass
            if menu_selection == 5:
                pass
            # option 6
            # call ConsoleGfx.display_image on image_data
            if menu_selection == 6:
                ConsoleGfx.display_image(image_data)
            if menu_selection == 7:
                pass
            if menu_selection == 8:
                pass
            if menu_selection == 9:
                pass
