from console_gfx import ConsoleGfx


if __name__ == '__main__':
    image_data = None
    # welcome message
    print('Welcome to the RLE image encoder.\n')

    # display test rainbow
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu = True
    while menu != False:
        print('''
        RLE Menu
        --------
        0. Exit
        1. Load File
        2. Load Test Image
        6. Display Image
        ''')

        menu_choice = int(input('Select a Menu Option: '))

        if menu_choice == 0:
            # Exits program
            menu = False

        if menu_choice == 1:
            # loads files
            filename = input('Enter name of file to load: ')
            image_data = ConsoleGfx.load_file(filename)

        if menu_choice == 2:
            # loads test image data
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.')

        if menu_choice == 6:
            # displays the image
            ConsoleGfx.display_image(image_data)

