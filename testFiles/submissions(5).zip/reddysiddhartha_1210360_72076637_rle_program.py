import console_gfx as cg

load = None
# Main menu
def main_menu():
    #declare load variable (for file to be displayed in future)
    global load
    # Menu options display
    print("RLE Menu \n-------- \n0. Exit \n1. Load File \n2. Load Test Image \n3. Read RLE String \n4. Read RLE Hex String \n5. Read Data Hex String \n6. Display Image \n7. Display RLE String \n8. Display Hex RLE Data \n9. Display Hex Flat Data")
    user_input = int(input("\nSelect a Menu Option: "))
    #exits program if input is 0
    if user_input == 0:
        exit
    #error for incorrect inputs
    elif user_input < 0 or user_input > 9:
        print("Error! Invalid input.\n")
        main_menu()
    #option 1 (load file)
    #--
    elif user_input == 1:
        filename = input("Enter name of file to load: ")
        print("")
        load = cg.ConsoleGfx.load_file(filename)
        main_menu()
    #option 2 (load test file)
    elif user_input == 2:
        load = cg.ConsoleGfx.test_image
        print("Test image data loaded.\n")
        main_menu()
    #option 6 (displays image)
    elif user_input == 6:
        print("Displaying image...")
        if load == None:
            print("(no data)\n")
        else:
            cg.ConsoleGfx.display_image(load)
            print("")
        main_menu()

#Welcome message
def welcome():
    print("Welcome to the RLE image encoder!")
    print("\nDisplaying Spectrum Image:")
    cg.ConsoleGfx.display_image(cg.ConsoleGfx.test_rainbow)

#Main (takes in user input based on menu options)
def main():
    welcome()
    main_menu()


main()