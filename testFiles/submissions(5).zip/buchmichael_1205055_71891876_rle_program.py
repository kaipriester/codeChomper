import console_gfx

image_loaded = [1, 1, 1]
#console_gfx.ConsoleGfx.display_image(image_loaded) // just wanted to see if I understood the code in console_gfx

def main():
      type_comparison_value = int(0)
      print("Welcome to the RLE image encoder!")
      print()
      print("Displaying Spectrum Image:")
      console_gfx.ConsoleGfx.display_image(console_gfx.ConsoleGfx.test_rainbow) #image correctly displayed
      choice_x = None #choosing None since having a preset value for choice_x could be an issue.
      while (choice_x != int(0)):
            print()
            print() #Menu is displayed here
            print("RLE Menu\n--------\n0. Exit\n1. Load File\n2. Load Test Image"
                        "\n3. Read RLE String\n4. Read RLE Hex String\n5. Read Data Hex String\n"
                        "6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex Flat Data")
            print()
            choice_x = input("Select a Menu Option: ")# below turns the string input into a int
            if((choice_x == "0") or
            (choice_x == "1") or#I recognize that I could just do "choice_x = int(input("...")"
            (choice_x == "2") or#but I feel programs like these should be *human* proof; I don't want it
            (choice_x == "3") or#to break simply because a person decided to toy around with this.
            (choice_x == "4") or
            (choice_x == "5") or#I also recognize the .isnumeric() method exists,but since I didn't
            (choice_x == "6") or#make it, using it feels like cheating since we also haven't gone over it.
            (choice_x == "7") or
            (choice_x == "8") or
            (choice_x == "9")):
                  choice_x = int(choice_x)

                  # ensures that what is chosen is actually a viable input
            if ((type(choice_x) != type(type_comparison_value))):
                  print("Error! Invalid input.")
                  continue
            if ((choice_x < int(0)) or (choice_x > int(9))):
                  print("Error! Invalid input.")
                  #This catches both multi-digit inputs AND negatives; both are invalid.

            if (choice_x == int(0)):
                  break
            if (choice_x == int(1)):
                  image_to_load = input("Enter name of file to load: ")
                  image_loaded = console_gfx.ConsoleGfx.load_file(image_to_load)
            if (choice_x == int(2)):
                  image_loaded = console_gfx.ConsoleGfx.test_image
                  print("Test image data loaded.")
            if (choice_x == int(3)):
                  print()
            if (choice_x == int(4)):
                  print()
            if (choice_x == int(5)):
                  print()
            if (choice_x == int(6)):
                  print("Displaying image...")
                  console_gfx.ConsoleGfx.display_image(image_loaded)
            if (choice_x == int(7)):
                  print()
            if (choice_x == int(8)):
                  print()
            if (choice_x == int(9)):
                  print()

if __name__ =="__main__":
      main()
