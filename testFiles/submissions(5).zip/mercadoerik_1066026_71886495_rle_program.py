from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''

# function definitions



if __name__ =='__main__':


    # main programs
    image_data = None

    # 1.welcome messages
    print("Welcome to the RLE image encoder!\n"
          "Displaying Spectrum Image:\n")



    # 2.display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)






    # 3. While loop to keep program prompting menu options
    menu = -1
    while menu != 0:
        print("\n"
              "RLE Menu\n"
              "--------\n"
              "0. Exit\n"
              "1. Load File\n"
              "2. Load Test Image\n"
              "3. Read RLE String\n"
              "4. Read RLE Hex String\n"
              "5. Read Data Hex String\n"
              "6. Display Image\n"
              "7. Display RLE String\n"
              "8. Display Hex RLE Data\n"
              "9. Display Hex Flat Data\n"
              "\n")


        # prompt user with menu option
        menu_option = int(input("Select a Menu Option: "))



        if menu_option == 0:
            break

        # option 1
        elif menu_option == 1:
            file_name = input("Enter name of file to load: ")
            image_data = ConsoleGfx.load_file(file_name)

            # load file and store data inside image_data
            # prompt for file name
            # call ConsoleGfx.load_file(filename) and store returned value in image_data

        # option 2
        elif menu_option == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

            # store ConsoleGfx.test_image in image_data


        elif menu_option == 3:
            pass

        elif menu_option == 4:
            pass

        elif menu_option == 5:
            pass

        elif menu_option == 6:
            ConsoleGfx.display_image(image_data)


        elif menu_option == 7:
            pass

        elif menu_option == 8:
            pass

        else:
            print("Error! Invalid input.")


