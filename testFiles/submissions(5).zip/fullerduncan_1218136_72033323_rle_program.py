"""
Title: Project 2A
Name: Duncan Fuller
Date: 10/02/2022
"""
# Import modules
from console_gfx import ConsoleGfx
from os.path import exists


# Display menu
def menu():
    print("""\nRLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data\n""")

    return choice_validation(input("Select a Menu Option: "))


# Validate user's selection
def choice_validation(choice):
    try:
        choice = int(choice)  # Try to convert to int in case of invalid input
    except ValueError:
        print("Error! Invalid input. Enter(0-9)")
        menu()
    else:
        if 0 <= choice <= 9:
            return choice  # If valid return value
        else:
            print("Error! Invalid input.")
            menu()  # Else call the menu method again for new input


# File import method
def import_file():
    filename = input("Enter name of file to load: ")
    while (".gfx" not in filename) or (not exists(filename)):  # Loops until file is a .gfx type and the file exist
        print("Invalid File. Please enter a .gfx file")
        filename = input("Enter name of file to load: ")
    return ConsoleGfx.load_file(filename)  # Shows a warning here, but it still works...


# Main method
def main():
    user_selection = -1  # Initialize variables
    file = "Empty"
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)  # Calling consolegfx to display rainbow
    print()

    while user_selection != 0:
        user_selection = menu()  # Calling menu method

        if user_selection == 1:
            file = import_file()  # Load file into program
        elif user_selection == 2:
            file = ConsoleGfx.test_image  # Load test image into program
            print("Test image data loaded.")
        elif user_selection == 3:
            pass
            # method call here
        elif user_selection == 4:
            pass
            # method call here
        elif user_selection == 5:
            pass
            # method call here
        elif user_selection == 6:
            # Verifying there is a file loaded before the call of the display image
            if file != "Empty":
                print("Displaying image...")
                ConsoleGfx.display_image(file)
            else:
                print("(no data)")

        elif user_selection == 7:
            pass
            # method call here
        elif user_selection == 8:
            pass
            # method call here
        elif user_selection == 9:
            pass
            # method call here

    print("GoodBye!")


if __name__ == '__main__':
    main()
