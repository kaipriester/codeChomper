from console_gfx import ConsoleGfx
#Imports what we need to make this code work from console_gfx.py

if __name__ == '__main__':
    image_data = None
    #image_data has no definition right now, so it is marked as none.
    print('Welcome to the RLE image encoder!')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow) #Displays your color spectrum

menu = -1
#Simply a placeholder value so that the while loop executes while also allowing menu to be defined.
while menu != 0:
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display RLE Data')
    print('9. Display Hex Flat Data')
    menu = int(input('Select a Menu Option:')) #Displays menu along with prompting the user for the option they want to select
    if menu == 1:
        filename = input('Enter name of file to load:')
        image_data = ConsoleGfx.load_file(filename)
    #Option 1 prompts the user to enter the name and directory of a file, then stores that file as file_data for later
    elif menu == 2:
        image_data = ConsoleGfx.test_image
    #assigns image_data with the test image
    elif menu == 6:
        if image_data != None:
            ConsoleGfx.display_image(image_data)
            #Displays the image created from what image_data has been assinged with from options 1 or two.
        else:
            print('Error: No images available to display!')
            #Failsafe incase image_data has none still attached to it
