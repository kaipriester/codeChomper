from console_gfx import ConsoleGfx
import testfiles


def main():
    image_data = None
    print(ConsoleGfx.test_rainbow)
    print("Welcome to the RLE image encoder!")
    print(end='\n')
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu = True
    while menu:
        print("RELE Menu")
        print("---------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display HEX RLE Data")
        print("9. Display Hex Flat Data")
        print(end='\n')
        print("Select a Menu Option: ", end=' ')
        option = int(input())

        if option == 0:
            menu = False
        elif option == 1:
            user_file = input('Enter name of file to load: ')
            image_data = ConsoleGfx.load_file(user_file)


        #option 1
            #load file and store the data inside image_data

        #option2
        elif option == 2:
            ConsoleGfx.display_image(ConsoleGfx.test_image)
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
        #option 6
        elif option == 6:
            ConsoleGfx.display_image(image_data)
main()