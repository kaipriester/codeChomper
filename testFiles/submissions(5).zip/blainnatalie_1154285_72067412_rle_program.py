from console_gfx import ConsoleGfx
# function definitions (8 of them)


def count_runs(flat):
    pass


def load_file(filename):
    file_data = []
    with open(filename, 'rb') as my_file:
        contents = my_file.read()
        for c in contents:
            file_data += [c]
        my_file.close()
    return file_data


def display_image(image_data):
    ConsoleGfx.display_image2(image_data, ConsoleGfx.default_top, ConsoleGfx.default_up_left, ConsoleGfx.default_up_right, ConsoleGfx.default_start,
                              ConsoleGfx.default_end, ConsoleGfx.default_bottom, ConsoleGfx.default_low_left, ConsoleGfx.default_low_right)
    return image_data


def display_image2(image_data, top, up_left, up_right, start, end, bottom, low_left, low_right):
    width = image_data[0]
    height = image_data[1]
    data_index = 2
    print(up_left, end='')
    for x_index in range(width):
        print(top, end='')
    print(up_right)
    for y_index in range(0, height, 2):
        output_str = start
        for x_index in range(width):
            output_color = image_data[data_index]
            output_str += ConsoleGfx.fg_palette[ConsoleGfx.TRANS_DISPLAY if output_color == ConsoleGfx.CLEAR else output_color]
            output_color = image_data[data_index + width] if y_index + 1 < height else ConsoleGfx.CLEAR
            output_str += ConsoleGfx.bg_palette[ConsoleGfx.TRANS_DISPLAY if output_color == ConsoleGfx.CLEAR else output_color]
            output_str += '▀'
            data_index += 1
        data_index += width
        print(output_str + ConsoleGfx.COLOR_RESET + end)
    print(low_left, end='')
    for x_index in range(width):
        print(bottom, end='')
    print(low_right)


# start of code for menu operations
menu_message = "\nRLE Menu\n--------"

zero = "0. Exit"
one = "1. Load File"
two = "2. Load Test Image"
three = "3. Read RLE String"
four = "4. Read RLE Hex String"
five = "5. Read Data Hex String"
six = "6. Display Image"
seven = "7. Display RLE String"
eight = "8. Display Hex RLE Data"
nine = "9. Display Hex Flat Data"
menu = f"{zero}\n{one}\n{two}\n{three}\n{four}\n{five}\n{six}\n{seven}\n{eight}\n{nine}\n"

if __name__ == "__main__":
    image_data = None
    file_loaded = None
    anything_loaded = False
# welcome messages
    print("Welcome to the RLE image encoder!\n\nDisplaying Spectrum Image:")
# display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
# while loop to keep prompting user to choose a menu option
    menu_choice = True
    while menu_choice:
        # prompt user for menu option
        print(menu_message)
        print(menu)
        user_option = int(input("Select a Menu Option: "))
        if (user_option < 0) or (user_option > 9):
            print("Error! Invalid input.")
            continue
        if user_option == 0:
            break
#  option 1
        if user_option == 1:
            file_loaded = input("Enter name of file to load: ")
            image_data = ConsoleGfx.load_file(file_loaded)
            anything_loaded = True
            continue
            # load the file (using ConsoleGfx) and store data inside image_data
            # call ConsoleGfx.load_file(filename) and store return value in image_data
# option 2
        if user_option == 2:
            print("Test image data loaded.")
            image_data = ConsoleGfx.test_image
            anything_loaded = True
            # load_file(ConsoleGfx.test_image)
            # store ConsoleGfx.test_image in image_data
            continue
# option 6
        if user_option == 6:
            if anything_loaded is False:
                print("Displaying image...\n(no data)")
            if anything_loaded is True:
                print("Displaying image...")
                print(ConsoleGfx.display_image(image_data))
            # called display_image in ConsoleGfx on file_loaded from option 1
            continue
