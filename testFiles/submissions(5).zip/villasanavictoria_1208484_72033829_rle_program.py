from console_gfx import ConsoleGfx as CG


def main():

    image = None
    menu_option = 1

    print('Welcome to the RLE image encoder!')

    print('Displaying Spectrum Image:')
    CG.display_image(CG.test_rainbow)
    print()

    while menu_option != 0:

        print("RLE Menu")
        print("-"*8)
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex PLE Data")
        print("9. Display Hex Flat Data")
        print()
        menu_option = int(input("Select a Menu Option:"))


        if menu_option == 0:
            break

        elif menu_option == 1:
            filename = input('Enter name of file to load: ')
            image = CG.load_file(filename)

        elif menu_option == 2:
            print('Test image data loaded')
            image = CG.test_image

        elif menu_option == 3:
            print('Not implemented')

        elif menu_option == 4:
            print('Not implemented')

        elif menu_option == 5:
            print('Not implemented')

        elif menu_option == 6:
            print('Displaying image...')

            if image is None:
                print('No data')
            else:
                CG.display_image(image)

if __name__ == '__main__':
    main()


