from console_gfx import ConsoleGfx

'''
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''


def count_runs(flat):
    pass


if __name__ == '__main__':
    image_data = None
    file_data = None
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu = 1
    while menu != 0:
        print()
        print()
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print()
        menu_option = input("Select a Menu Option: ")

        if menu_option == '1':
            filename = input("Enter a menu selection: ")
            file_data = ConsoleGfx.load_file(filename)
            image_data = file_data

        elif menu_option == '2':
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        elif menu_option == '6':
            if image_data is not None:
                print("Displaying image...")
                ConsoleGfx.display_image(image_data)
















