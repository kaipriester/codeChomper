from console_gfx import ConsoleGfx
print('Welcome to the RLE image encoder!')
print('\nDisplaying Spectrum Image:')
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
loaded_file = ConsoleGfx.test_rainbow
game_over = False


def menu():  # prints menu and asks for user input
    print('\nRLE Menu\n--------\n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String')
    print('4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image')
    print('7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex Flat Data')
    menu_option = input('\nSelect a Menu Option: ')
    return menu_option


while not game_over:  # Executes different menu options based on user input
    menu_option = menu()
    if menu_option == '1':
        file_to_load = input('Enter name of file to load: ')
        loaded_file = ConsoleGfx.load_file(file_to_load)
    if menu_option == '2':
        loaded_file = ConsoleGfx.test_image
        print('Test image data loaded')
    elif menu_option == '6':
        print('Displaying image...')
        ConsoleGfx.display_image(loaded_file)
