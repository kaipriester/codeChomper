from console_gfx import ConsoleGfx

if __name__ == '__main__':
    image_data = None
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()
    print()

    menu = -1
    while menu != 0:
        print('RLE Menu')
        print('________')
        print('0. Exit')
        print('1. Load File')
        print('2. Load Test Image')
        print('3. Read RLE String')
        print('4. Read RLE Hex String')
        print('5. Read Data Hex String')
        print('6. Display Image')
        print('7. Display RLE String')
        print('8. Display Hex RLE Data')
        print('9. Display Hex Flat Data')
        print()
       
        menu = int(input('Select a Menu Option: '))
        if menu == 1:
            filename = input('Enter name of file to load: ')
            image_data = ConsoleGfx.load_file(filename)
            print()
        elif menu == 2:
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.')
            print()
        elif menu == 6:
            print('Displaying image...')
            ConsoleGfx.display_image(image_data)
            print()

