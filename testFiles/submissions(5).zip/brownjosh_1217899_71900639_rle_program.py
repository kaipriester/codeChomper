from console_gfx import ConsoleGfx


def print_menu():
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')


def main():
    print()
    print()
    option = None
    option_2_check = False
    # option_2_check used to check if the test image was loaded
    file_to_load = None
    while option != 0:
        print_menu()
        print()
        option = input('Select a Menu Option: ')
        if option == '1':
            file_to_load = input('Enter name of file to load: ')
            print()
            ConsoleGfx.load_file(file_to_load)
        elif option == '2':
            print('Test image data loaded.')
            print()
            option_2_check = True
            file_to_load = ConsoleGfx.test_image
        elif option == '3':
            return
        elif option == '4':
            return
        elif option == '5':
            return
        elif option == '6':
            print('Displaying image...')
            # checks if option_2_check is truthy
            if option_2_check:
                ConsoleGfx.display_image(file_to_load)
                # option_2_check is reset to let other images be loaded.
                option_2_check = False
                print()
            else:
                ConsoleGfx.display_image(ConsoleGfx.load_file(file_to_load))
                print()
        elif option == '7':
            return
        elif option == '8':
            return
        elif option == '9':
            return
        elif option == '0':
            return
        else:
            return


if __name__ == '__main__':
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:\n')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    main()
