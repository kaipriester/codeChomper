from console_gfx import ConsoleGfx

# print(ConsoleGfx.test_rainbow)

# ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

# Watched the lecture guiding on how to do this project

# function definition
def count_runs(flat):
    pass


if __name__ == '__main__':
    # main program
    image_data = None
    # welcome message
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")
    # display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # while loop to keep prompting user to choose menu option
    menu_display = True
    while menu_display:
        # loads menu & prompts user to enter option
        print()
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String ")
        print("8. Display RLE Hex String")
        print("9. Display Hex Flat Data")
        print()
        option = int(input("Select a menu option: "))

        # option 1
        if option == 1:
            # gets file name from user
            file_name = input("Enter name of file to load: ")
            # loads the file name and stores it in image_data
            image_data = ConsoleGfx.load_file(file_name)

        # option 2
        if option == 2:
            # stores ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image

        # option 6
        if option == 6:
            # displays the current image stored in image_data
            ConsoleGfx.display_image(image_data)
