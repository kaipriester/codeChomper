# Code structure is used from Prof. Zhou's lecture video.
from console_gfx import ConsoleGfx
ConsoleGfx()

# Define menu() function to display menu options.
def menu():
    print()
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")

if __name__ == "__main__":
    # Store initial value of image_data and display welcome messages with a test_rainbow image.
    image_data = None
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    # Display menu options and prompt the user to select an option.
    loop_on = True
    while loop_on:
        menu()
        user_input = int(input("Select a Menu Option: "))
        # If user selects 0, exit out of the program and display goodbye message.
        if user_input == 0:
            loop_on = False
            print("Goodbye!")
        # If user selects 1, load file name and store it to image_data.
        elif user_input == 1:
            file_name = input("Enter name of file to load: ", )
            image_data = ConsoleGfx.load_file(file_name)
        # If user selects 2, load test image and store it to image_data.
        elif user_input == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
        # If user selects 6, display selected image.
        elif user_input == 6:
            print("Displaying image...")
            ConsoleGfx.display_image(image_data)
