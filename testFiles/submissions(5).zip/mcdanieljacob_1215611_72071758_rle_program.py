user_pick = 18
import colors
loaded_file = 0
print('Welcome to the RLE image encoder!')
print("")
print("Displaying Spectrum Image:")
colors.ConsoleGfx.display_image(colors.ConsoleGfx.test_rainbow)
while user_pick != 0:
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")
    print("")
    user_pick = int(input("Select a Menu Option:"))
    if user_pick == 1:
        loaded_file = input("Enter name of file to load: ")
        loaded_file = colors.ConsoleGfx.load_file(loaded_file)
    elif user_pick == 2:
        loaded_file = colors.ConsoleGfx.test_image
        print("Test image data loaded")
    elif user_pick == 6:
        print("Displaying Image")
        colors.ConsoleGfx.display_image(loaded_file)
    else:
        user_pick = 0
