from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''


# define functions
def display_menu():
    print()
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')
    print()

image_data = None

if __name__ == '__main__':
    # main program
    menu = ''
    # welcome message
    print('Welcome to the RLE image encoder!')
    print()
    # display test_rainbow
    print(f'Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    display_menu()

    while menu != 0:
        # load file and store data inside image_data
        menu = int(input('Select a Menu Option: '))
        if menu == 1:
            filename = (input('Enter name of file to load: '))
            image_data = ConsoleGfx.load_file(filename)
            display_menu()
        # store ConsoleGfx.test_image in image_data
        elif menu == 2:
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.')
            display_menu()
        # store ConsoleGfx
        elif menu == 3:
            pass
        elif menu == 4:
            pass
        elif menu == 5:
            pass
        # displays image_data
        elif menu == 6:
            ConsoleGfx.display_image(image_data)
        elif menu == 7:
            pass
        elif menu == 8:
            pass
        elif menu == 9:
            pass
