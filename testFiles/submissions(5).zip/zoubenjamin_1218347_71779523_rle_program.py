from console_gfx import ConsoleGfx        # import the ConsoleGfx class from console_gfx file


if __name__ == "__main__":                             # main driver function

    image_data = None                # sets initial image data value

    print("Welcome to the RLE image encoder! ")                       # welcome message
    print()
    print("Displaying Spectrum Image: ")

    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)           # spectrum display

    menu_display = True
    while menu_display:                                   # loop that displays menu
        print()
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print("")

        user_choice = int(input("Select a Menu Option: "))            # user input for menu

        if user_choice == 0:
            menu_display = False                                   # exit choice

        elif user_choice == 1:
            file_name = input("Enter name of file to load: ")
            image_data = ConsoleGfx.load_file(file_name)                    # loads file

        elif user_choice == 2:
            print("Test image data loaded.")                                   # loads the test data
            # store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image

        elif user_choice == 6:
            ConsoleGfx.display_image(image_data)
            # call display_image in ConsoleGfx on image_data              # displays image to the console

            