from console_gfx import ConsoleGfx


def display_greeting():
    print("Welcome to the RLE image encoder!\n")

def display_test():
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print("\n")

def display_menu():  #easy call for printing the menu and keeping the code cleaned up
    print("\
RLE Menu\n\
--------\n\
0. Exit\n\
1. Load File\n\
2. Load Test Image\n\
3. Read RLE String\n\
4. Read RLE Hex String\n\
5. Read Data Hex String\n\
6. Display Image\n\
7. Display RLE String\n\
8. Display Hex RLE Data\n\
9. Display Hex Flat Data\n\
    ")

def get_file_location():  #not really necessary to turn into a function, but keeps the code clean and easy to read
    file_path = input("Enter name of file to load: ")
    return file_path

def load_image(file):
    ConsoleGfx.load_file(file)

def get_input():
    correct = False
    while not correct:
        display_menu()
        choice = int(input("Select a Menu Option: "))
        if choice == 0:
            quit()
        elif 0 < choice <= 9:
            correct = True
        else:
            print()
            print("Invalid input!")
            print("Please enter an integer value between 0 and 9.")
            print()
            continue
        print()
    return choice

def main():
    display_greeting()
    display_test()
    while True:
        menu_choice = get_input()
        if menu_choice == 1:
            file_location = get_file_location()
            image_file = ConsoleGfx.load_file(file_location)
        elif menu_choice == 2:
            ConsoleGfx.display_image(ConsoleGfx.test_image)

        elif menu_choice == 6:
            ConsoleGfx.display_image(image_file)
        """elif menu_choice == 3:
            break
        elif menu_choice == 4:
            break
        elif menu_choice == 5:
            break
        elif menu_choice == 7:
            break
        elif menu_choice == 8:
            break
        elif menu_choice == 9:
            break"""


        print()


main()