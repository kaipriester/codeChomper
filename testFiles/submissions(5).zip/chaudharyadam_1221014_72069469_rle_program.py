from console_gfx import ConsoleGfx as CG

def print_menue():
    print('\nRLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')
    print('\nSelect a Menu Option:')

def main():
    image_data = None
    exit_prog = False
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    CG.display_image(CG.test_rainbow)
    print()
    while exit_prog == False:
        print_menue()   # prompts the user for menue choices
        user_choice = int(input())  # gets user's input
        if user_choice == 0:    # exits program
            exit_prog = True
        elif user_choice == 1:  # loads user selected file
            filename = str(input('Enter name of file to load: '))
            image_data = CG.load_file(filename)
        elif user_choice == 2:  # loads test file
            print('Test image data loaded.')
            image_data = CG.test_image
        elif user_choice == 6:  # prints current file loaded
            CG.display_image(image_data)

if __name__ == '__main__':
    main()
