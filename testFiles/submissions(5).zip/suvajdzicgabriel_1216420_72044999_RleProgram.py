
from console_gfx import ConsoleGfx

print('Welcome to the RLE image encoder!')
print()
print('Displaying Spectrum Image')
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
print()


def menu():
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')


exit_program = 0
load_data = 0

while exit_program == 0:
    print()
    menu()
    print()
    user_choice = int(input('Select a Menu Option:'))
    if user_choice == 0:
        exit_program = 1
    elif user_choice == 1:
        file_name = input('Enter name of file to load:')
        load_data = ConsoleGfx.load_file(file_name)
    elif user_choice == 2:
        load_data = ConsoleGfx.test_image
        print('Test image data loaded.')
    elif user_choice == 3:
        something
    elif user_choice == 4:
        something
    elif user_choice == 5:
        something
    elif user_choice == 6:
        print('Displaying Image...')
        if load_data == 0:
            print('(no data)')
        else:
            ConsoleGfx.display_image(load_data)
    elif user_choice == 7:
        something
    elif user_choice == 8:
        something
    elif user_choice == 9:
        something
    else:
        print('Error! Invalid input.')


