from console_gfx import ConsoleGfx


image_data = None
menu_option = 1

print("Welcome ot the RLE image encoder!")

print("Displaying Spectrum Image:")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
print()

while True:
    print("RLE Menu")
    print("---------")
    print("0: Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex PLE Data")
    print("9. Display Hex Flat Data")
    print()
    option = int(input("Select a Menu Option: "))
    if option == 0:
        break
    elif option == 1:
        image_data = input("Enter name of file to load: ")
        ConsoleGfx.load_file(image_data)
        image = ConsoleGfx.load_file(image_data)
    elif option == 2:
        print("Test image data loaded")
        image = ConsoleGfx.test_image
    elif option == 6:
        print("Displaying image...")
        if image == None :
            print("No data to display")
        else :
            ConsoleGfx.display_image(image)


