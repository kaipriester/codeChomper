'''
Kaleb Hoenisch
10/04/2022
Professor Kapoor
COP3502C
Fall 2022
'''

from console_gfx import ConsoleGfx

def welcome_menu():
    print("Welcome to the RLE image encoder!")
    print("\nDisplaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print("")
    print("\nRLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")

if __name__ == "__main__":
    image_data = None
    welcome_menu()
    menu_option = 1
    while menu_option != "0":
        menu_option = input("\nSelect a Menu Option: ")
        if menu_option == "1":
            file_to_load = input("Enter name of file to load: ")
            image_data = ConsoleGfx.load_file(file_to_load)
        elif menu_option == "2":
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        #Put code for other options in order here.

        elif menu_option == "6":
            ConsoleGfx.display_image(image_data)