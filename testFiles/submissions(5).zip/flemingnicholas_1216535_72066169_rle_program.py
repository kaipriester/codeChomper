from console_gfx import ConsoleGfx

choice = -1

def menu():
    print('\nRLE menu\n--------')
    print('0. Exit\n1. Load File\n2. Load Test Image\n' +
    '3. Read RLE String\n4. Read RLE Hex String\n' +
    '5. Read Data Hex String\n6. Display Image\n' +
    '7. Display RLE String\n8. Display Hex RLE Data\n' +
    '9. Display Hex Flat Data\n')


def main(choice):
    
    image = ''
    
    print('Welcome to the RLE image encoder!\n')

    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    while choice != 0:
        menu()
        choice = int(input('Select a Menu Option: '))

        if choice == 0:
            break
        elif choice == 1:
            image = input('Enter name of file to load: ')
            image = ConsoleGfx.load_file(image)
        elif choice == 2:
            image = ConsoleGfx.test_image
            print('Test image data loaded.')
        elif choice == 6:
            print('Displaying image...')
            ConsoleGfx.display_image(image)
    

main(choice)
