# Abdulkadir Husein
# Lab 02 - Image RLE


from console_gfx import ConsoleGfx



# function definitions
def count_runs(flat):
    pass


if __name__ == "__main__":
    # main program
    image_data = None

    # welcome message
    print("Welcome to the RLE image encoder!\n")

    # spectrum image
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu = -1
    while menu != 0:
        # menu
        print("\nRLE Menu\n" + "________\n" + "0. Exit\n" + "1. Load File\n" + "2. Load Test Image\n" + "3. Read RLE String\n" + "4. Read RLE Hex String\n" + "5. Read Data Hex String\n" + "6. Display Image\n" + "7. Display RLE String\n" + "8. Display Hex RLE Data\n" + "9. Display Hex Flat Data\n")

        # prompt
        option = int(input("Select a Menu Option: "))

        # option 1
        if option == 1:
            filename = input("Enter name of file to load: ")
            ConsoleGfx.load_file(filename)

        # option 2
        if option == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        # option 6
        if option == 6:
            ConsoleGfx.display_image(image_data)






