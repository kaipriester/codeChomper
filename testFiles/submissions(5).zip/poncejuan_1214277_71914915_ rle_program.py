from console_gfx import ConsoleGfx


def welcome_message():
    print("Welcome to the RLE image encoder!", '\n')


def spectrum_image():
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print('\n')


def display_rle_menu():
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data", '\n')

    print("Select a Menu Option:")


if __name__ == "__main__":

    image_data = None
    filename = None
    welcome_message()
    spectrum_image()

    while True:

        display_rle_menu()
        menu_option = int(input())

        if menu_option == 1:
            filename = input("Enter name of file to load: ")

            image_data = ConsoleGfx.load_file(filename)

        if menu_option == 2:

            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        if menu_option == 6:
            if image_data != 'None':
                ConsoleGfx.display_image(image_data)

            else:
                print("Displaying image...")
                print("(no data)")