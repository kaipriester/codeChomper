from console_gfx import ConsoleGfx

''' 
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

'''
menu = True

# count_number = 0
# def count_runs(flat):
#      count_number = count_number + 1
#      pass
#

if __name__ == '__main__':
    # main program
    image = None

    print("Welcome to the RLE image encoder! \n")                    # welcome message
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    print("\n\nRLE Menu")
    print("---------------")

    print(f"0. Exit")
    print(f"1. Load File")
    print(f"2. Load Test Image")
    print(f"3. Read RLE String")
    print(f"4. Read RLE Hex String")
    print(f"5. Read Data Hex String")
    print(f"6. Display Image")
    print(f"7. Display RLE String")
    print(f"8. Display Hex RLE Data")
    print(f"9. Display Hex Flat Data \n")
    print('Select a Menu Option:')

    option = int(input())

    menu = 1
    while menu != 0:

        if option == 1:
            filename = input('Enter name of file to load:')
            image = ConsoleGfx.load_file(filename)
            print()

        elif option == 2:
            print('Test image data loaded.')
            image = ConsoleGfx.test_image

        elif option == 6:
            print('Displaying image...')
            ConsoleGfx.display_image(image)

        elif option == 0:
            menu = False
            break

        print('Select a Menu Option:')
        option = int(input())



        '''        
        
             if option == 7:
                  print('Display the RLE string:', RLE string display
             
             if option == 8:
                  print('RLE Hex values:', RLE Hex values)   
                  
             if option == 9:
                  print('Flat Hex values:', Flat values)             
                  
        
        
        
             #2. display the test_rainbow
        
             ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
        
             #3 Use while loop to keep prompting the user to choose a menu option
        
             menu = -1
             while menu!=0:
        
                 # option 1
        
                    # load file and store the data inside image_data
                          # prompt for the file name
                          # call ConsoleGfx.load_file(filename) and store returned value in image_data
        
        
                 # option 2
                    # store ConsoleGfx.test_image in image_data
        
        
        
        
                 # option 6
                    # call display_image in ConsoleGfx on image_data
                    
        '''
