from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''

# functions defined outside loop
def displaymenu():
    print(f'\nRLE Menu\n'
          f'--------\n'
          f'0. Exit\n'
          f'1. Load File\n'
          f'2. Load Test Image\n'
          f'3. Read RLE String\n'
          f'4. Read RLE Hex String\n'
          f'5. Read Data Hex String\n'
          f'6. Display Image\n'
          f'7. Display RLE String\n'
          f'8. Display Hex RLE Data\n'
          f'9. Display Hex Flat Data')


if __name__ == '__main__':
    # main program
    image_data = None
    image_data_ = None
    # Welcome message
    print("Welcome to the RLE image encoder!")
    print("")

    # display the test_rainbow
    print("Displaying Spectrum Image: ")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print('')

    menu = True
    while menu:

        displaymenu()

        # prompt user for menu
        option = int(input("\nSelect a Menu Option: "))

        # option 0 - exit
        if option == 0:
            menu = False

        # option 1 - load file and store data in image_data
        if option == 1:
            file_name = input("Enter name of file to load: ")
            ConsoleGfx.image_data = ConsoleGfx.test_image
            image_data = ConsoleGfx.load_file(file_name)
            image_data_ = True
            continue

        # option 2 -
        if option == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
            image_data_ = True
            continue

        # option 6
        if option == 6:
            if image_data_:
                print("Displaying image...")
                print(ConsoleGfx.display_image(image_data))
                continue
            elif image_data is None:
                print("(no data)")
                continue
