from console_gfx import ConsoleGfx

# Count method
def count_runs(flat):
    pass

# Menu method
def menu():
    #Image data resets to None
    image_data = None

    # Variable for menu while loop
    menu = -1

    # While loop for menu
    while menu != 0:

        # Print welcome message
        print("Welcome to the RLE image encoder!\n")
        print("Displaying Spectrum Image:")
        ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
        print("RLE menu")
        print("--------")
        # Print menu options
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data\n")
        # User inputs a menu option
        menu_option = int(input("Select a Menu Option: "))

        # Menu option 1
        if menu_option == 1:
            # Print message for input
            file_name = str(input("Enter name of file to load: "))
            # Calling Console Gfx, loads file and stores returned value in image_data
            image_data = ConsoleGfx.load_file(file_name)
            # Newline
            print()


        # Menu option 2
        elif menu_option == 2:
            # Print message for input
            print("Test image data loaded.")
            #Calling Console Gfx, loads test image and stores returned value in image_data
            image_data = ConsoleGfx.test_rainbow
            # Newline
            print()

        # Menu option 6
        elif menu_option == 6:
            # Display image_data image
            ConsoleGfx.display_image(image_data)
            # Newline
            print()



# Main method
def main():

    while(True):
        # Calling menu method
        menu()


# Calling main method
main()


