from console_gfx import ConsoleGfx
# Structure from Prof. Zhou's walkthrough
if __name__ == '__main__':
    image_data = None
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu = -1
    while menu != 0:
        print('\nRLE Menu\n'
              '--------\n'
              '0. Exit\n'
              '1. Load File\n'
              '2. Load Test Image\n'
              '3. Read RLE String\n'
              '4. Read RLE Hex String\n'
              '5. Read Data Hex String\n'
              '6. Display Image\n'
              '7. Display RLE String\n'
              '8. Display Hex RLE Data\n'
              '9. Display Hex Flat Data\n')
        option = int(input('Select a Menu Option: '))
        if option == 1:
            file_name = input('Enter name of file to load: ')
            image_data = ConsoleGfx.load_file(file_name)
        if option == 2:
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.')
        if option == 6:
            ConsoleGfx.display_image(image_data)
        if option == 0:
            break

