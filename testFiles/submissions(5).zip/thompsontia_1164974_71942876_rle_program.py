from console_gfx import ConsoleGfx

image_data = "(no data)"

#standalone menu
#Display welcome message
print("Welcome to the RLE image encoder!")
print()
print("Displaying Spectrum Image:")

#display color test
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

#Display the menu
print()
print("RLE Menu")
print("--------")
print("0. Exit")
print("1. Load File")
print("2. Load Test Image")
print("3. Read RLE String")
print("4. Read RLE Hex String")
print("5. Read Data Hex String")
print("6. Display Image")
print("7. Display RLE String")
print("8. Display Hex RLE Data")
print("9. Display Hex Flat Data")
print()
#prompt for input
while True:
    menu_option = int(input("Select a Menu Option: "))
    if menu_option == 0:
        break
    if 0 < menu_option <= 9:
        if menu_option == 1:
            #accepts a file name from the user and invokes
            #ConsoleGfx.loadFile(String filename):
            image_data = ConsoleGfx.load_file(input("Enter name of file to load: "))
            print()
            print("RLE Menu")
            print("--------")
            print("0. Exit")
            print("1. Load File")
            print("2. Load Test Image")
            print("3. Read RLE String")
            print("4. Read RLE Hex String")
            print("5. Read Data Hex String")
            print("6. Display Image")
            print("7. Display RLE String")
            print("8. Display Hex RLE Data")
            print("9. Display Hex Flat Data")
            print()

        if menu_option == 2:
            # Loads ConsoleGfx.testImage:
            if image_data == "(no data)":
                print("(no data)")
            else:
                print("Test image data loaded.")
                print()
                print("RLE Menu")
                print("--------")
                print("0. Exit")
                print("1. Load File")
                print("2. Load Test Image")
                print("3. Read RLE String")
                print("4. Read RLE Hex String")
                print("5. Read Data Hex String")
                print("6. Display Image")
                print("7. Display RLE String")
                print("8. Display Hex RLE Data")
                print("9. Display Hex Flat Data")
                print()

        if menu_option == 3:
            # Reads RLE data from the user in decimal
            # notation with delimiters (smiley example):
            print()

        if menu_option == 4:
            # Reads RLE data from the user in hexadecimal
            # notation without delimiters (smiley example):
            print()

        if menu_option == 5:
            # Reads raw (flat) data from the user in hexadecimal
            # notation (smiley example):
            print()

        if menu_option == 6:
            # Displays the current image by invoking the ConsoleGfx.displayImage
            # (imageData) method.
            print("Displaying Image...")
            if image_data == "(no data)":
                print("(no data)")
                print()
                print("RLE Menu")
                print("--------")
                print("0. Exit")
                print("1. Load File")
                print("2. Load Test Image")
                print("3. Read RLE String")
                print("4. Read RLE Hex String")
                print("5. Read Data Hex String")
                print("6. Display Image")
                print("7. Display RLE String")
                print("8. Display Hex RLE Data")
                print("9. Display Hex Flat Data")
                print()
            else:
                ConsoleGfx.display_image(image_data)
                print()
                print("RLE Menu")
                print("--------")
                print("0. Exit")
                print("1. Load File")
                print("2. Load Test Image")
                print("3. Read RLE String")
                print("4. Read RLE Hex String")
                print("5. Read Data Hex String")
                print("6. Display Image")
                print("7. Display RLE String")
                print("8. Display Hex RLE Data")
                print("9. Display Hex Flat Data")
                print()

        if menu_option == 7:
            # Converts the current data into a human-readable
            # RLE representation (with delimiters):
            print()

        if menu_option == 8:
            # Converts the current data into RLE hexadecimal
            # representation (without delimiters):
            print()

        if menu_option == 9:
            # Displays the current raw (flat) data in hexadecimal
            # representation (without delimiters):
            print()

    if menu_option > 9:
        print("Error! Invalid input.")
    if menu_option < 0:
        print("Error! Invalid input.")
