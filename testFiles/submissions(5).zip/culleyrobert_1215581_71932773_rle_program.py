from console_gfx import ConsoleGfx


rle_running = True

#insantiate image_file variable
image_file = ''


# 1)  Display welcome message
print('Wecome to the RLE image encoder!')

# 2)  Display color test (ConsoleGfx.testRainbow)
print('Displaying Spectrum Image: ')
print(ConsoleGfx.display_image(ConsoleGfx.test_rainbow))

while rle_running:

    # 3)  Display the menu

    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')

    # 4)  Prompt for input
    menu_option = int(input('Select a Menu Option: '))

#option 1 will load a file image and store the file name into the image_file variable
    if menu_option == 1:
        image_file = input('Enter name of the file to load: ')
        print(ConsoleGfx.load_file(image_file))

#option 2 will load the test image and store the file name into the image_file variable
    elif menu_option == 2:
        image_file = ConsoleGfx.test_image
        print('Test image data loaded.')

#option 6 will display the image file
    elif menu_option == 6:
        print(ConsoleGfx.display_image(image_file))
