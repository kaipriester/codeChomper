from console_gfx import ConsoleGfx


def menu():
    print()
    print('RLE Menu\n--------\n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex String')
    print('5. Read Data Hex String\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE String')
    print('9. Display Hex Flat Data\n')


if __name__ == '__main__':

    show_menu = True
    no_image_data = True
    image_data = None

    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu()

    while show_menu:

        command = int(input('Select a menu option: '))

        if command == 1:
            filename = input('Enter name of the file to load: ')
            image_data = ConsoleGfx.load_file(filename)
            no_image_data = False
            menu()
            continue

        elif command == 2:
            image_data = ConsoleGfx.test_image
            no_image_data = False
            print('Test image data loaded.')
            menu()
            continue

        elif command == 6:

            if no_image_data:
                print('(no data)')
                menu()
                continue

            else:
                ConsoleGfx.display_image(image_data)
                menu()
                continue

        else:
            print('Error! Invalid input.')
            menu()
            continue
