from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_image)
print(ConsoleGfx.test_rainbow)

ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''


def count_runs(flat):
    pass

if __name__='__main__':
        #main program
    image_data= None
    #1. welcome messages
    #2. display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    #3.use while loop to keep prompting
    menu=-1

    while menu != 0:
        #4. PRompt the user for menu option
        print('RLE Menu')
        print('--------')
        print('0. Exit')
        print('1. Load File')
        print('2. Load Test Image')
        print('3. Read RLE String')
        print('4. Read RLE Hex String')
        print('5. Read Data Hex String')
        print('6. Display Image')
        print('7. Display RLE String')
        print('8 Display Hex RLE Data')
        print('9. Display Hex Flat Data')
        
        print('Select a Menu Option:')
        
        print('Displaying image...')
        # option 1:
            #load file and store data inside image_data
                # prompt for file name
                # call ConsoleGfx.load_file(filename) store returned value in data.

        # option 2:
            # store ConsoleGfx.test_image in image_data

        # option 6:
            #call display_image in ConsoleGfx on image_data


