from console_gfx import ConsoleGfx
print('Welcome to the RLE image encoder!')
print(' ')
print('Displaying Spectrum Image:')

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''
#printing the menu
def print_menu():
    print('\nRLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data\n')

#set up the main
def main():
    print_menu()
    image_data = 0

#all of the output functions
    while True:

        print('Select a Menu Option:')
        menu = int(input())

        if menu == 0:
            break
        elif menu == 1:
            filename = input('Enter name of file to load:')
            image_data = ConsoleGfx.load_file(filename)
        elif menu == 2:
            # image_data = ConsoleGfx.load_file(ConsoleGfx.test_image)
            image_data = ConsoleGfx.test_image
        elif menu == 6:
            print("Displaying image...")

#image display
            if image_data != 0:
                ConsoleGfx.display_image(image_data)
                print("Image should have been displayed!")
            else:
                print("You Suck!")


if __name__ == '__main__':
    # main program
    # 1. welcome messages
    # 2. display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. use while loop to keep prompting the user to choose a menu option
    main()