from console_gfx import ConsoleGfx


# Define function to print the menu
def print_menu():
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')
    print()


if __name__ == '__main__':
    ''' Main program'''

    image_data = None  # Initialize image_data

    print('Welcome to the RLE image encoder!')
    print()
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()
    print()

    # Main While loop to print menu, get user selection and perform function
    # Complete Option 1, 2, and 6 for project 2A
    menu_go = True  # Initialize menu_go boolean to run main while loop

    while menu_go:
        print_menu()
        menu_selection = input('Select a Menu Option: ')
        menu_selection = int(menu_selection)
        if menu_selection == 0:
            print('Option 0 selected')
            break
        elif menu_selection == 1:
            # Prompt the user for the file name and Load the file data, store in image_data
            filename = input('Enter name of file to load: ')
            print()
            image_data = ConsoleGfx.load_file(filename)
        elif menu_selection == 2:
            # Load the test image and store in image_data
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.')
            print()
        elif menu_selection == 3:
            print('FIXME: Option 3 selected')
        elif menu_selection == 4:
            print('FIXME: Option 4 selected')
        elif menu_selection == 5:
            print('FIXME: Option 5 selected')
        elif menu_selection == 6:
            # Display image data
            ConsoleGfx.display_image(image_data)
            print()
        elif menu_selection == 7:
            print('FIXME: Option 7 selected')
        elif menu_selection == 8:
            print('FIXME: Option 8 selected')
        elif menu_selection == 9:
            print('FIXME: Option 2 selected')
        else:
            print('Invalid selection')
