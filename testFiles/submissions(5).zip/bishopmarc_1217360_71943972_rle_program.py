# Marc Bishop
# Last Edit 10/1/22

# import ConsoleGfx
from console_gfx import ConsoleGfx

# print welcoming display and test image
print("Welcome to the RLE image encoder!\n")
print("Displaying Spectrum Image:")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
print()

# initialize image data variable
image = None

# set program on to true
program_on = True

# start while loop to continue running the program until user exits
while program_on:

    # display menu and options
    print("RLE Menu")
    print("-" * 8)
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")

    # set up while loop to test user inputs for errors
    while True:
        try:
            # ask for user input
            user_input = int(input("Select a Menu Option: "))
            print()

            # set up if statements to check user input and provide appropriate output
            # if statement to stop program
            if user_input == 0:
                program_on = False
                break

            # ask user to enter the file name they want to load
            if user_input == 1:
                filename = input("Enter name of file to load: ")
                image = ConsoleGfx.load_file(filename)
                print()
                break

            if user_input == 2:
                image = ConsoleGfx.test_image
                break

            if user_input == 3:
                break

            if user_input == 4:
                break

            if user_input == 5:
                break

            # display image of loaded user file
            if user_input == 6:
                print("Displaying image. . .")
                ConsoleGfx.display_image(image)
                print()
                break

            if user_input == 7:
                break

            if user_input == 8:
                break

            if user_input == 9:
                break

            if user_input < 0:
                break

            if user_input > 9:
                break

        except ValueError:
            break
