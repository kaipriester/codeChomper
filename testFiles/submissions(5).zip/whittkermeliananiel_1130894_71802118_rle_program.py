# Aniel A. Whittker Melian, 09/24/2022

from console_gfx import ConsoleGfx

# Executes when runned as a script
if __name__ == '__main__':
    # image_date is assigned to None
    image_data = None
    # displays welcome message
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")
    # displays the test_rainbow image from the imported module
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()
    print()

    # display_menu is assigned with True for the while loop
    display_menu = True

    # while loop that displays the menu and performs operations based on input
    while display_menu:
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print()

        # prompts the user to select an option, entering an integer
        user_input = int(input("Select a Menu Option:"))

        # if user inputs 1, it prompts the user to enter a file name,
        # it loads the file, then it stores the return value in image_data
        if user_input == 1:
            file_name = input("Enter name of file to load:")
            ConsoleGfx.load_file(file_name)
            image_data = ConsoleGfx.load_file(file_name)

        # else if user inputs 2, it displays that the image is loaded,
        # then it stores the return value in image_data
        elif user_input == 2:
            print("Test image data loaded.")
            image_data = ConsoleGfx.test_image

        # else if user inputs 6, it displays the image stored in image_data
        elif user_input == 6:
            ConsoleGfx.display_image(image_data)



# Sources
# followed through lecture video and used same variable name image_data, M3 Project 2A walkthrough











































