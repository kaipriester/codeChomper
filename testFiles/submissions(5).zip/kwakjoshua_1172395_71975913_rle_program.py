
import console_gfx

ConsoleGfx = console_gfx.ConsoleGfx

import dataConversions

convert = dataConversions.Convert

##def print_img:
    ##print('FIX')

def menu():
    print()
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')
    print()
    usr_inp = input('Select a Menu Option: ')
    return usr_inp


choice = -1
fileData = []

print('Welcome to the RLE image encoder:')
print()
print('Displaying Spectrum Image:')

ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

while choice != 0:
    choice = int(menu())

    if choice == 0:
        break

    elif choice == 1:
        usrFile = input('Enter name of file to Load: ')
        fileData = ConsoleGfx.load_file(str(usrFile))

    elif choice == 2:
        flatRle = convert.encode_rle(ConsoleGfx.test_image)
        fileData = flatRle
        print('Test image data loaded.')

    elif choice == 3:
        usrData = input('Enter an RLE string to be decoded: ')
        strRle = convert.string_to_rle(usrFile)
        fileData = strRle

    elif choice == 4:
        usrData = input('Enter the hex string holding RLE data: ')
        hexRle = convert.string_to_data(usrData)
        fileData = hexRle

    elif choice == 5:
        usrData = input('Enter the hex string holding flat data: ')
        hexFlat = convert.string_to_data(usrData)
        flatRle = convert.encode_rle(hexFlat)
        fileData = flatRle

    elif choice == 6:
        if fileData == []:
            print('Displaying image...')
            print('(no data)')
        else:
            print('Displaying image...')
            imageData = convert.decode_rle(fileData)
            ConsoleGfx.display_image(imageData)

    elif choice == 7:
        if fileData == []:
            rleRead = '(no data)'
        else:
            rleRead = convert.to_rle_string(fileData)
        print(f'RLE representation: {rleRead}')

    elif choice == 8:
        if fileData == []:
            rleHex = '(no data)'
        else:
            rleHex = convert.to_hex_string(fileData)
        print(f'RLE hex values: {rleHex}')

    elif choice == 9:
        if fileData == []:
            decodeFlat = '(no data)'
        else:
            rleDecode = convert.decode_rle(fileData)
            decodeFlat = convert.to_hex_string(rleDecode)
        print(f'Flat hex values: {decodeFlat}')
    else:
        print('Error! Invalid input.')

