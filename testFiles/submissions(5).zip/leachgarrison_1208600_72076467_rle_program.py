from console_gfx import ConsoleGfx

# print(ConsoleGfx.test_rainbow)
# ConsoleGfx.display_image(ConsoleGfx.test_rainbow)


def count_runs(flat):
    pass


if __name__ == '__main__':
    image_data = None
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image: ")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()

    menu = True
    while menu:
        print()
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print()
        print("Select a Menu Option: ", end="")
        user_choice = int(input())
        if user_choice == 1:
            print("Enter name of file to load: ", end="")
            filename = input()
            image_data = ConsoleGfx.load_file(filename)
        if user_choice == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
        if user_choice == 6:
            if image_data is not None:
                print("Displaying image...")
                ConsoleGfx.display_image(image_data)
