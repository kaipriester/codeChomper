from console_gfx import ConsoleGfx
from typing import Callable


class ConsoleGfxApp:
    def __init__(self) -> None:
        # FIXME: self.menu_functions works as ref. guide;
        #  might be implemented in later.
        self.menu_functions: dict[int, Callable] = {
            -1: self.menu_and_option,
            0: quit,
            1: self.load_file,
            2: self.load_test_image,
            3: self.read_rle_str,
            4: self.read_rle_hex_str,
            5: self.read_rle_hex_str_flat,
            6: self.display_image,
            7: self.display_rle_str,
            8: self.display_rle_hex_str,
            9: self.display_rle_hex_str_flat,
        }
        self.image = []
        self.rle_str: str = '(no data)\n'
        self.rle_hex: str = '(no data)\n'
        self.rle_raw: str = '(no data)\n'

    def load_file(self) -> list[str]:
        """Accepts a filename from the user and invokes ConsoleGfx.load_file()."""

        file_name = input('Enter name of the file to load: ')
        file_data = ConsoleGfx.load_file(file_name)
        self.image = file_data

        # Newline
        print()

        return file_data

    def load_test_image(self) -> list:
        """Loads ConsoleGfx.test_image."""

        self.image = ConsoleGfx.test_image
        print('Test image data loaded.\n')

        return ConsoleGfx.test_image

    def read_rle_str(self) -> str:
        """Reads RLE data from the user in decimal notation w/ delimiters."""

        rle_str = input('Enter an RLE string to be decoded: ')
        self.rle_str = rle_str

        return rle_str

    def read_rle_hex_str(self) -> str:
        """Reads RLE data from the user in hexadecimal notation w/o delimiters."""

        rle_hex = input('Enter the hex string holding RLE data: ')
        self.rle_hex = rle_hex

        return rle_hex

    def read_rle_hex_str_flat(self) -> str:
        """Reads raw (flat) data from the user in hexadecimal notation."""

        rle_raw = input('Enter the hex string holding flat data: ')
        self.rle_raw = rle_raw

        return rle_raw

    def display_image(self) -> None:
        """Displays the current loaded image by invoking ConsoleGfx.displayImage()."""

        print('Displaying image...')

        if self.image:
            ConsoleGfx.display_image(self.image)
            print()
        else:
            print('(no data)\n')

    @staticmethod
    def display_rle_str(data) -> None:
        """Converts the current data into a human-readable RLE representation (w/ delimiters)."""

        pass

    @staticmethod
    def display_rle_hex_str(data) -> None:
        """Converts the current data into RLE hexadecimal representation (w/o delimiters)."""

        pass

    @staticmethod
    def display_rle_hex_str_flat(data) -> None:
        """Displays the current raw (flat) data in hexadecimal representation (w/o delimiters)."""

        pass

    @staticmethod
    def to_hex_string(data: list[int]) -> str:
        """Translate data (RLE or raw) to a hexadecimal string (w/o delimiters)."""

        pass

    @staticmethod
    def count_runs(flat_data: list[int]) -> int:
        """Returns the number of runs of data in an image dataset."""

        pass

    @staticmethod
    def encode_rle(flat_data: list[int]) -> list[int]:
        """Returns encoding (RLE) of the raw data passed in."""

        pass

    @staticmethod
    def get_decoded_length(rle_data: list[int]) -> int:
        """Returns decompressed size of RLE data."""

        pass

    @staticmethod
    def decode_rle(rle_data: list[int]) -> list[int]:
        """Returns the decoded data set from RLE encoded data."""

        pass

    @staticmethod
    def string_to_data(data_string: str) -> list[int]:
        """Translates a string in hexadecimal format into byte data (raw or RLE)."""

        pass

    @staticmethod
    def to_rle_string(rle_data: list[int]) -> str:
        """Translate RLE data into a human-readable representation."""

        pass

    @staticmethod
    def string_to_rle(rle_string: str) -> list[int]:
        """Translates a RLE string (w/ delimiters) into RLE byte data."""

        pass

    @staticmethod
    def print_to_console(func, newline: bool = True) -> Callable:
        """Decorator to print the return string(s) of a function."""

        def wrapper():
            lines: list = func()

            for line in lines:
                print(line)

            if newline:
                print()

        return wrapper

    @staticmethod
    def welcome_msg() -> None:
        """Displays the welcome message."""

        print('Welcome to the RLE image encoder!\n')

    @staticmethod
    def colour_test() -> None:
        """Displays the colour test."""

        print('Displaying Spectrum Image:')
        ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
        print()

    @staticmethod
    @print_to_console
    def menu() -> list[str]:
        """Displays the menu."""

        msg = [
            'RLE Menu',
            '--------',
            '0. Exit',
            '1. Load File',
            '2. Load Test Image',
            '3. Read RLE String',
            '4. Read RLE Hex String',
            '5. Read Data Hex String',
            '6. Display Image',
            '7. Display RLE String',
            '8. Display Hex RLE Data',
            '9. Display Hex Flat Data',
        ]

        return msg

    @staticmethod
    def choose_menu_option() -> str:
        """Accepts an input from the user to choose a menu option."""

        menu_choice = input('Select a Menu Option: ')

        return menu_choice

    @staticmethod
    def menu_choice_to_int(menu_choice: str) -> int:
        """Converts the user's menu choice (str) to an integer."""

        try:
            menu_choice_int = int(menu_choice)
        except (ValueError, TypeError):
            menu_choice_int = -1
        finally:
            if not 0 <= menu_choice_int <= 9:
                print('Error! Invalid input.\n')
                menu_choice_int = -1

        return menu_choice_int

    def menu_and_option(self) -> str:
        """Invokes the menu() and choose_menu_option() functions, for convenience."""

        self.menu()
        menu_choice = self.choose_menu_option()
        menu_choice_int = self.menu_choice_to_int(menu_choice)

        return menu_choice_int

    def standalone_mode(self) -> int:
        """Invokes welcome_msg(), colour_test(), menu(), and choose_menu_option()."""

        self.welcome_msg()
        self.colour_test()
        self.menu()
        menu_choice = self.choose_menu_option()
        menu_choice_int = self.menu_choice_to_int(menu_choice)

        return menu_choice_int

    '''
    def get_menu_action(self, menu_choice: int) -> Callable:
        """Returns the function associated with the user's menu choice."""

        # FIXME (22.09.27): May have to rework implementation.
        # ... isn't clear what can be done after the func returns.
        return self.menu_functions.get(menu_choice)
    '''

    def main(self) -> None:
        """Runs the main program."""

        exit_program: bool = False
        show_header: bool = True

        while not exit_program:

            if show_header:
                menu_choice = self.standalone_mode()
            else:
                menu_choice = self.menu_and_option()

            if menu_choice == 0:
                exit_program = True
            elif menu_choice == 1:
                self.load_file()
            elif menu_choice == 2:
                self.load_test_image()
            elif menu_choice == 6:
                self.display_image()
            else:
                pass

            show_header = False


if __name__ == '__main__':
    app = ConsoleGfxApp()
    app.main()
