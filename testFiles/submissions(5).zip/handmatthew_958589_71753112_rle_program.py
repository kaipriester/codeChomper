import console_gfx
from console_gfx import ConsoleGfx

print('Welcome to the RLE image encoder!')
print('\nDisplaying Spectrum Image: ')
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

def Menu():
    global loaded_file

    print('\nRLE Menu \n--------\n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex Flat Data')
    selection = input(('\nSelect a Menu Option: '))

    if selection == '1':
        file = input('Enter name of file to load: ')
        loaded_file = ConsoleGfx.load_file(file)
        return loaded_file
    if selection == '2':
        loaded_file = ConsoleGfx.test_image
        print('Test image data loaded.')
        return loaded_file
    if selection == '6':
        ConsoleGfx.display_image(loaded_file)
        loaded_file = None

loop = 1
while loop == 1:
    Menu()
#gator = ConsoleGfx.load_file('gator.gfx')
#ConsoleGfx.display_image(gator)
