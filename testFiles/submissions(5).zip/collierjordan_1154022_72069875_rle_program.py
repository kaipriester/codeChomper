from console_gfx import ConsoleGfx


def rle_menu():
    menu1 = "RLE Menu \n" + "-------- \n"
    menu2 = "0. Exit \n" + "1. Load File \n" + "2. Load Test Image \n" + "3. Read RLE String \n"
    menu3 = "4. Read RLE Hex String \n" + "5. Read Data Hex String \n" + "6. Display Image \n"
    menu4 = "7. Display RLE String \n" + "8. Display Hex RLE String \n" + "9. Display Hex Flat Data \n"
    return menu1 + menu2 + menu3 + menu4


print('Welcome to the RLE image encoder! \n')  # welcome message
print('Displaying Spectrum Image:')
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
print('')
print(rle_menu())
option = float(input('Select a Menu Option: '))

while option != 0:  # this is how the entire thing is going to operate
    if option == 1:
        file_name = input('Enter a name of file to load: ')  # unsure what to do with input and how to resolve error
        ConsoleGfx.load_file(file_name)  # supposed to change data type?
        print(rle_menu())
        option = float(input('Select a Menu Option: '))
    elif option == 2:
        ConsoleGfx.display_image(ConsoleGfx.test_image)
        print(rle_menu())
        option = float(input('Select a Menu Option: '))
    elif option == 6:
        ConsoleGfx.display_image()
        print(rle_menu())
        option = float(input('Select a Menu Option: '))

while option == 0:  # close the function
    option = "done"
