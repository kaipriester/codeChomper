import console_gfx
ConsoleGfx = console_gfx.ConsoleGfx        #https://www.geeksforgeeks.org/how-to-import-a-class-from-another-file-in-python/

def menu():
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")
    print()


print("Welcome to the RLE image encoder!\n")
print("Displaying Spectrum Image:")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
print()



def image_data(file_name):                                            # testfiles\fsu.gfx, testfiles\gator.gfx, testfiles\lsu.gfx, testfiles\uga.gfx, testfiles\ut.gfx
    file_data = []
    with open(file_name, 'rb') as my_file:
        contents = my_file.read()
        for c in contents:
            file_data += [c]

    my_file.close()
    return file_data

testimage_loaded = False



while True:

    menu()
    select = int(input("Select a Menu Option:"))

    if select == 0:
        quit()
    elif select == 1:
        file_name = input("Enter name of file to load:")
        ConsoleGfx.load_file(file_name)
    elif select == 2:
        print("Test image data loaded.\n")
        testimage_loaded = True
    elif select == 3:
        pass
    elif select == 4:
        pass
    elif select == 5:
        pass
    elif select == 6:
        print("Displaying image...\n")
        if testimage_loaded == True:
            ConsoleGfx.display_image(ConsoleGfx.test_image)
            testimage_loaded = False
        else:
            ConsoleGfx.display_image(image_data(file_name))
    elif select == 7:
        pass
    elif select == 8:
        pass
    elif select == 9:
        pass
    else:
        print("Error! Invalid input.\n")
