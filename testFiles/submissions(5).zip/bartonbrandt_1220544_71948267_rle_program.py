'''
Name: Brandt Barton
Date: 10/01/2022
Course: COP3502C Fall 2022
Proj: Proj2A - rle_program

'''

# Importing the required image processing functions.
from console_gfx import ConsoleGfx

# Function to call for printing the menu.
def disp_menu():
    '''
    disp_menu

    This function prints the options menu

    :return: no return, just prints the menu

    '''

    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')
    print()


# Function for printing the rainbow image.
def rainbow():
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

# Function for printing the test image.
def disp_test_image():
        ConsoleGfx.display_image(ConsoleGfx.test_image)


# Main function will call other functions depending on the users input
def rle_main():

    menu_choice = -1

    print('Welcome to the RLE image encoder!')
    print()
    print('Displaying Spectrum Image:')


    rainbow()

    print()
    disp_menu()

    while menu_choice != 0:


        menu_choice = int(input('Select a Menu Option: '))


        if menu_choice == 1:
            file_path = input('Enter name of file to load: ')
            file_data = ConsoleGfx.load_file(file_path)
            print()

        elif menu_choice == 2:

            file_data = ConsoleGfx.test_image
            print('Test image data loaded.')
            print()

        elif menu_choice == 6:
            ConsoleGfx.display_image(file_data)
            print()

        elif menu_choice == 0:
            break

        else:
            print("Invalid Choice. Please enter an option from the menu.")
            print()


if __name__ == '__main__':
    rle_main()

