from console_gfx import ConsoleGfx
def count_runs(flat):
    pass
if __name__ == '__main__':
    #main program
    image_data = None
    print('Welcome to the RLE image encoder!\n\nDisplaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    #use while loop for menu options
    while True:
        print("RLE Menu\n--------\n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex Flat Data")
        user_input = int(input('Select a Menu Option: '))
        if user_input == 1:
            user_file = input('Enter name of file to load:')
            image_data = ConsoleGfx.load_file(user_file)
        if user_input == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
        if user_input == 6:
            ConsoleGfx.display_image(image_data)


        #option 1
            #load file and store data inside image_data
                #prompt for file name
                #call ConsoleGfx.load_file(filename) and store returned value in image_data


        #option 2
            # store ConsoleGfx.test_image in image_data
        #option 3

        #option 6
            #call display_image in ConsoleGfx on image_data