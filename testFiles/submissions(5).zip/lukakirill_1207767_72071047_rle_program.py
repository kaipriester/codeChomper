from console_gfx import ConsoleGfx


if __name__ == "__main__":
    image_data = None
    # prints welcome message
    print("Welcome to the RLE image encoder!\n")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    menu = 0
    while menu != 1:
        print("\n\nRLE Menu\n--------\n0. Exit\n1. Load file\n2. Load test image\n3. Read RLE String\n4. Read RLE Hex String")
        print("5. Read Data Hex String\n6. Display Image\n7. Display RLE data\n8. Display RLE Flat Data\n")
        option = int(input("Select a Menu Option: "))
        if option == 1:
            # load file and store data inside image data
            filename = input("Enter file name: ")
            image_data = ConsoleGfx.load_file(filename)
        elif option == 2:
            # load test image in image data
            image_data = ConsoleGfx.test_image
        elif option == 6:
            # Displays image
            ConsoleGfx.display_image(image_data)



