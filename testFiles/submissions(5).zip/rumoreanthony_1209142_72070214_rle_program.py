import console_gfx as c_gfx


def main():
    image = (0, 0)

    # Displays the welcome message & color test
    print('Welcome to the RLE image encoder!')

    console_gfx = c_gfx.ConsoleGfx
    print('\nDisplaying Spectrum Image:')
    console_gfx.display_image(console_gfx.test_rainbow)
    print()

    menu_choice = -1

    while menu_choice != 0:

        # Displays the RLE Menu
        print()
        print('RLE Menu')
        print('--------')
        print('0. Exit')
        print('1. Load File')
        print('2. Load Test Image')
        print('3. Read RLE String')
        print('4. Read RLE Hex String')
        print('5. Read Data Hex String')
        print('6. Display Image')
        print('7. Display RLE String')
        print('8. Display Hex RLE Data')
        print('9. Display Hex Flat Data')
        print()

        menu_choice = int(input('Select a Menu Option: '))

        if menu_choice == 1:
            # load file
            file = input('Enter name of file to load: ')
            image = console_gfx.load_file(file)

        elif menu_choice == 2:
            # load test image
            image = console_gfx.test_image

        elif menu_choice == 6:
            # display image
            console_gfx.display_image(image)

        elif menu_choice in (3, 4, 5, 7, 8, 9):
            print('Functionality not implemented yet.')

        elif menu_choice == 0:
            print('Error! Invalid input.')


if __name__ == '__main__':
    main()
