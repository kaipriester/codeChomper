/*eslint no-delete-var: "error"*/

var x;
delete x;
